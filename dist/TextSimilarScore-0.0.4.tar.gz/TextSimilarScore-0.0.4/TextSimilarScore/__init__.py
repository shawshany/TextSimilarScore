#!/usr/bin/python3
# -*-coding:utf-8 -*-
#Reference:**********************************************
# @Time     : 2019-09-12 14:48
# @Author   : 病虎
# @E-mail   : victor.xsyang@gmail.com
# @File     : __init__.py
# @User     : ora
# @Software: PyCharm
#Reference:**********************************************
name = "TextSimilarScore"